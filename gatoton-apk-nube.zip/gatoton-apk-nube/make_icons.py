import os
from PIL import Image
R='android/app/src/main/res'
a=Image.open('icon-512.png').convert('RGB'); m=Image.open('icon-maskable-512.png').convert('RGB')
for d,l,f in [('mdpi',48,108),('hdpi',72,162),('xhdpi',96,216),('xxhdpi',144,324),('xxxhdpi',192,432)]:
    p=f'{R}/mipmap-{d}'; os.makedirs(p,exist_ok=True)
    for n in ('ic_launcher','ic_launcher_round'):
        a.resize((l,l),Image.LANCZOS).save(f'{p}/{n}.png')
    m.resize((f,f),Image.LANCZOS).save(f'{p}/ic_launcher_foreground.png')
os.makedirs(f'{R}/values',exist_ok=True)
open(f'{R}/values/ic_launcher_background.xml','w').write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#0A0709</color>\n</resources>\n')
